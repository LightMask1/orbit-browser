// Cloudflare Pages advanced-mode Worker. Browsing traffic stays on this origin.
const noCache = { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'x-robots-tag': 'noindex, nofollow' };
const json = (body, status = 200) => Response.json(body, { status, headers: noCache });

export function validateTarget(value, origin, websocket = false) {
  const url = new URL(value);
  const protocols = websocket ? ['ws:', 'wss:'] : ['http:', 'https:'];
  if (!protocols.includes(url.protocol) || url.username || url.password) throw new Error('Only public web addresses are supported.');
  const host = url.hostname.toLowerCase().replace(/\.$/, '');
  // Only DNS names are supported. Reject IP literals, local names, and metadata endpoints.
  if (!host.includes('.') || /[\[\]:]/.test(host) || /^[\d.]+$/.test(host) ||
      /(^|\.)(localhost|local|internal|lan|home|test|invalid|onion|arpa)$/.test(host) ||
      host === 'metadata.google.internal' || host === new URL(origin).hostname) throw new Error('That address is not a public website.');
  if (url.port && !['80', '443'].includes(url.port)) throw new Error('Only standard web ports are supported.');
  return url;
}

function readBareHeaders(headers) {
  let value = headers.get('x-bare-headers');
  if (headers.has('x-bare-headers-0')) {
    const pieces = [];
    for (let i = 0; headers.has(`x-bare-headers-${i}`); i++) {
      const part = headers.get(`x-bare-headers-${i}`);
      if (!part.startsWith(';') || i > 64) throw new Error('Invalid request headers.');
      pieces.push(part.slice(1));
    }
    value = pieces.join('');
  }
  if (!value || value.length > 131072) throw new Error('Invalid request headers.');
  const parsed = JSON.parse(value);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Invalid request headers.');
  return parsed;
}

function outgoingHeaders(input, websocket = false) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(input)) {
    if (/^(host|connection|upgrade|content-length|transfer-encoding|accept-encoding|cf-.*|x-forwarded-.*|forwarded|proxy-.*|sec-websocket-key|sec-websocket-version|sec-websocket-extensions)$/i.test(name)) continue;
    if (typeof value !== 'string' && !(Array.isArray(value) && value.every(v => typeof v === 'string'))) throw new Error('Invalid request headers.');
    for (const item of Array.isArray(value) ? value : [value]) headers.append(name, item);
  }
  if (websocket) headers.set('upgrade', 'websocket');
  else headers.set('accept-encoding', 'identity');
  return headers;
}

function remoteHeaders(headers) {
  const result = Object.fromEntries(headers);
  const cookies = headers.getSetCookie?.() || [];
  if (cookies.length) result['set-cookie'] = cookies;
  return result;
}

function writeBareHeaders(headers, values) {
  const value = JSON.stringify(values);
  if (value.length <= 3072) headers.set('x-bare-headers', value);
  else for (let offset = 0, i = 0; offset < value.length; offset += 3072, i++) headers.set(`x-bare-headers-${i}`, ';' + value.slice(offset, offset + 3072));
}

function sameOrigin(request) {
  const origin = request.headers.get('origin');
  const site = request.headers.get('sec-fetch-site');
  return (!origin || origin === new URL(request.url).origin) && (!site || site === 'same-origin' || site === 'none');
}

async function proxyHttp(request) {
  const target = validateTarget(request.headers.get('x-bare-url'), request.url);
  const headers = outgoingHeaders(readBareHeaders(request.headers));
  const upstream = await fetch(target.href, {
    method: request.method,
    headers,
    body: ['GET', 'HEAD'].includes(request.method) ? undefined : request.body,
    redirect: 'manual',
    signal: AbortSignal.timeout(45000),
    cf: { cacheTtl: 0, cacheEverything: false },
  });
  const responseHeaders = new Headers(noCache);
  responseHeaders.set('content-type', 'application/octet-stream');
  responseHeaders.set('x-bare-status', String(upstream.status));
  responseHeaders.set('x-bare-status-text', upstream.statusText);
  writeBareHeaders(responseHeaders, remoteHeaders(upstream.headers));
  // Preserve compressed streaming responses; the browser decodes the outer response.
  const encoding = upstream.headers.get('content-encoding');
  if (encoding) responseHeaders.set('content-encoding', encoding);
  return new Response(request.method === 'HEAD' ? null : upstream.body, { status: 200, headers: responseHeaders, encodeBody: 'manual' });
}

function proxyWebSocket(request) {
  const pair = new WebSocketPair();
  const [client, server] = Object.values(pair);
  server.accept();
  let upstream;
  let state = 'waiting';
  const close = () => {
    state = 'closed';
    clearTimeout(deadline);
    try { server.close(1000, 'Connection closed'); } catch {}
    try { upstream?.close(1000, 'Connection closed'); } catch {}
  };
  const deadline = setTimeout(close, 10000);
  server.addEventListener('message', async event => {
    if (state === 'open') { try { upstream.send(event.data); } catch { close(); } return; }
    if (state !== 'waiting') { close(); return; }
    state = 'connecting';
    try {
      if (typeof event.data !== 'string' || event.data.length > 131072) throw new Error('Invalid handshake');
      const message = JSON.parse(event.data);
      if (message.type !== 'connect' || !Array.isArray(message.protocols) || !message.protocols.every(p => typeof p === 'string')) throw new Error('Invalid handshake');
      const target = validateTarget(message.remote, request.url, true);
      target.protocol = target.protocol === 'wss:' ? 'https:' : 'http:';
      const headers = outgoingHeaders(message.headers || {}, true);
      if (message.protocols.length) headers.set('sec-websocket-protocol', message.protocols.join(', '));
      const response = await fetch(target.href, { headers, redirect: 'manual', signal: AbortSignal.timeout(10000) });
      if (!response.webSocket || state === 'closed') throw new Error('WebSocket unavailable');
      upstream = response.webSocket;
      upstream.accept();
      upstream.addEventListener('message', event => { try { server.send(event.data); } catch { close(); } });
      upstream.addEventListener('close', close);
      upstream.addEventListener('error', close);
      clearTimeout(deadline);
      server.send(JSON.stringify({ type: 'open', protocol: response.headers.get('sec-websocket-protocol') || '', setCookies: response.headers.getSetCookie?.() || [] }));
      state = 'open';
    } catch { close(); }
  });
  server.addEventListener('close', close);
  server.addEventListener('error', close);
  return new Response(null, { status: 101, webSocket: client });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/health') return json({ status: 'ok', service: 'Orbit', transport: 'Cloudflare Bare v3' });
    if (!url.pathname.startsWith('/bare/')) return env.ASSETS.fetch(request);
    if (!sameOrigin(request)) return json({ code: 'ORIGIN_DENIED', message: 'Open this connection from Orbit.' }, 403);
    if (url.pathname === '/bare/') return json({ versions: ['v3'], language: 'ServiceWorker', project: { name: 'Orbit', version: '1.0.0' } });
    if (url.pathname !== '/bare/v3/') return json({ code: 'NOT_FOUND', message: 'Unknown proxy endpoint.' }, 404);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: noCache });
    if (['CONNECT', 'TRACE'].includes(request.method)) return json({ code: 'METHOD_DENIED', message: 'Unsupported method.' }, 405);
    try {
      if (request.headers.get('upgrade')?.toLowerCase() === 'websocket') return proxyWebSocket(request);
      return await proxyHttp(request);
    } catch (error) {
      const message = error instanceof TypeError || /address|port|headers/.test(error.message) ? error.message : 'The website did not respond. Try again or choose another site.';
      return json({ code: 'PROXY_ERROR', message }, 502);
    }
  },
};
