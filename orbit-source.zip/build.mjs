import { cp, copyFile, mkdir, readdir, rm, readFile, writeFile } from 'node:fs/promises';
import { build } from 'esbuild';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
await rm('dist', { recursive: true, force: true });
await cp('public', 'dist', { recursive: true });
const vendors = [
  ['@mercuryworkshop/scramjet', 'scram', ['scramjet.all.js', 'scramjet.sync.js', 'scramjet.wasm.wasm']],
  ['@mercuryworkshop/bare-mux', 'baremux', ['index.js', 'index.mjs', 'worker.js']],
  ['@mercuryworkshop/bare-as-module3', 'baremod', ['index.mjs']],
];
await mkdir('dist/licenses', { recursive: true });
let licenseLinks = '';
for (const [name, directory, files] of vendors) {
  await mkdir(join('dist', directory), { recursive: true });
  for (const file of files) await copyFile(join('node_modules', name, 'dist', file), join('dist', directory, file));
  await copyFile(join('node_modules', name, 'LICENSE'), join('dist/licenses', directory + '.txt'));
  licenseLinks += `<li><a href="${directory}.txt">${name}</a></li>`;
}
await writeFile('dist/licenses/index.html', `<!doctype html><meta charset="utf-8"><title>Orbit open-source notices</title><style>body{background:#111;color:#ddd;font:16px system-ui;max-width:700px;padding:50px;margin:auto}a{color:#e7b263}li{margin:18px 0}</style><h1>Open-source notices</h1><p>Orbit is distributed under AGPL-3.0-only. <a href="/source.zip">Download Orbit source</a>. It includes unmodified browser distributions of these components. Their licenses and source are available below.</p><ul>${licenseLinks}</ul><p><a href="https://github.com/MercuryWorkshop/scramjet/tree/57ba89e">Scramjet 1.1.0 source</a> · <a href="https://github.com/MercuryWorkshop/bare-mux">Bare Mux source</a> · <a href="https://github.com/MercuryWorkshop/bare-transport">Bare transport source</a></p>`);
await build({ entryPoints: ['src/worker.js'], outfile: 'dist/_worker.js', bundle: true, format: 'esm', platform: 'browser', target: 'es2022', minify: true });
execFileSync('zip', ['-q', '-r', 'dist/source.zip', 'public', 'src', 'build.mjs', 'package.json', 'package-lock.json', 'wrangler.toml', 'README.md', 'LICENSE', '.gitignore']);
console.log('Built Orbit: Cloudflare Pages advanced-mode Worker and self-hosted proxy assets.');
