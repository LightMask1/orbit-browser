(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const icon = name => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem('orbit.' + key)) ?? fallback; } catch { return fallback; } };
  const write = (key, value) => { try { localStorage.setItem('orbit.' + key, JSON.stringify(value)); } catch { /* Browsing still works if storage is unavailable. */ } };
  const defaultShortcuts = [
    { name: 'YouTube', url: 'https://www.youtube.com/', mark: 'youtube' },
    { name: 'Google', url: 'https://www.google.com/', mark: 'G' },
    { name: 'Discord', url: 'https://discord.com/', mark: 'discord' },
    { name: 'Reddit', url: 'https://www.reddit.com/', mark: 'reddit' },
    { name: 'GitHub', url: 'https://github.com/', mark: 'github' },
    { name: 'Wikipedia', url: 'https://en.wikipedia.org/', mark: 'W' },
  ];
  let shortcuts = read('shortcuts', defaultShortcuts);
  let bookmarks = read('bookmarks', []);
  const settings = read('settings', { engine: 'duckduckgo', accent: '#e7b263' });
  const tabs = [];
  let activeId, nextId = 0, toastTimer, controller, enginePromise, ready = false, routeError = '';
  const activeTab = () => tabs.find(tab => tab.id === activeId);
  const engines = { google: 'https://www.google.com/search?q=', duckduckgo: 'https://duckduckgo.com/?q=', bing: 'https://www.bing.com/search?q=' };
  const markSvg = {
    youtube: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="5" width="20" height="14" rx="5" fill="currentColor" stroke="none"/><path d="m10 9 5 3-5 3Z" fill="#141416" stroke="none"/></svg>',
    github: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 0 0-3.2 19.5c.5.1.7-.2.7-.5v-1.9c-2.8.6-3.4-1.2-3.4-1.2-.5-1.2-1.2-1.5-1.2-1.5-1-.6.1-.6.1-.6 1.1.1 1.6 1.1 1.6 1.1 1 1.6 2.5 1.1 3 .9.1-.7.4-1.1.7-1.3-2.2-.3-4.5-1.1-4.5-5 0-1.1.4-2 1-2.7-.1-.3-.4-1.3.1-2.7 0 0 .8-.3 2.8 1a9.5 9.5 0 0 1 5.1 0c2-1.3 2.8-1 2.8-1 .5 1.4.2 2.4.1 2.7.6.7 1 1.6 1 2.7 0 3.9-2.3 4.7-4.5 5 .4.3.7.9.7 1.8V21c0 .3.2.6.7.5A10 10 0 0 0 12 2Z" fill="currentColor" stroke="none"/></svg>',
    discord: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 5c-2-1-4-1-4-1l-.5 1a14 14 0 0 0-5 0L9 4S7 4 5 5c-2 3-3 7-3 11 2 2 5 3 5 3l1-2c-1-.3-2-.9-2-.9 4 2 8 2 12 0 0 0-1 .6-2 .9l1 2s3-1 5-3c0-4-1-8-3-11Z" fill="currentColor" stroke="none"/><circle cx="8" cy="12" r="1.5" fill="#141416" stroke="none"/><circle cx="16" cy="12" r="1.5" fill="#141416" stroke="none"/></svg>',
    reddit: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 8 1-5 5 1"/><circle cx="19" cy="4" r="2"/><ellipse cx="12" cy="14" rx="9" ry="7"/><circle cx="8" cy="13" r="1" fill="currentColor"/><circle cx="16" cy="13" r="1" fill="currentColor"/><path d="M8 17c2 2 6 2 8 0"/></svg>',
  };

  function toast(message) {
    clearTimeout(toastTimer); $('toast').textContent = message; $('toast').hidden = false;
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3500);
  }
  function applySettings() { document.documentElement.style.setProperty('--accent', /^#[a-f0-9]{6}$/i.test(settings.accent) ? settings.accent : '#e7b263'); }
  applySettings();
  function targetFor(input) {
    const value = input.trim();
    if (!value) return null;
    if (/^[a-z][\w+.-]*:/i.test(value) && !/^https?:/i.test(value)) throw new Error('Enter an http or https web address.');
    if (/^https?:\/\//i.test(value) || (!/\s/.test(value) && /^[^/]+\.[^/]+/.test(value))) {
      const url = new URL(/^https?:/i.test(value) ? value : 'https://' + value);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('Enter a public website without a username or password in the URL.');
      return url.href;
    }
    return (engines[settings.engine] || engines.duckduckgo) + encodeURIComponent(value);
  }

  async function initEngine() {
    if (enginePromise) return enginePromise;
    enginePromise = (async () => {
      if (!('serviceWorker' in navigator) || !('SharedWorker' in window)) throw new Error('Orbit needs a browser with service worker and shared worker support. Try a current version of Chrome, Edge, Firefox, or Safari.');
      const { ScramjetController } = $scramjetLoadController();
      controller = new ScramjetController({
        prefix: '/browse/',
        files: { wasm: '/scram/scramjet.wasm.wasm', all: '/scram/scramjet.all.js', sync: '/scram/scramjet.sync.js' },
        flags: { rewriterLogs: false, captureErrors: false, cleanErrors: true },
      });
      await controller.init();
      await navigator.serviceWorker.register('/sw.js', { scope: '/' });
      await navigator.serviceWorker.ready;
      if (!navigator.serviceWorker.controller) await new Promise(resolve => navigator.serviceWorker.addEventListener('controllerchange', resolve, { once: true }));
      const connection = new BareMux.BareMuxConnection('/baremux/worker.js');
      await connection.setTransport('/baremod/index.mjs', [new URL('/bare/', location.href).href]);
      const health = await fetch('/health', { cache: 'no-store', signal: AbortSignal.timeout(10000) });
      if (!health.ok || (await health.json()).status !== 'ok') throw new Error('The proxy connection is unavailable. Please try again in a moment.');
      ready = true; routeError = '';
      $('connection').className = 'connection ready'; $('connection-text').textContent = 'Connection ready';
      return controller;
    })().catch(error => {
      routeError = error.message; $('connection').className = 'connection error'; $('connection-text').textContent = 'Connection unavailable';
      enginePromise = null; throw error;
    });
    return enginePromise;
  }

  function renderTabs() {
    $('tabs').replaceChildren();
    for (const tab of tabs) {
      const item = document.createElement('div'); item.className = 'browser-tab' + (tab.id === activeId ? ' active' : '');
      const select = document.createElement('button'); select.className = 'tab-select'; select.setAttribute('role', 'tab'); select.setAttribute('aria-selected', tab.id === activeId); select.setAttribute('aria-label', tab.title);
      select.innerHTML = icon(tab.url ? 'globe' : 'orbit');
      const name = document.createElement('span'); name.className = 'tab-title'; name.textContent = tab.title; select.append(name); select.onclick = () => activate(tab.id);
      const close = document.createElement('button'); close.className = 'close-tab'; close.setAttribute('aria-label', 'Close ' + tab.title); close.innerHTML = icon('close'); close.onclick = () => closeTab(tab.id);
      item.append(select, close); $('tabs').append(item);
    }
  }

  function syncChrome() {
    const tab = activeTab(); if (!tab) return;
    $('address').value = tab.url || '';
    $('back').disabled = tab.cursor <= 0;
    $('forward').disabled = tab.cursor >= tab.history.length - 1;
    $('reload').disabled = !tab.url;
    $('bookmark').disabled = !tab.url;
    const saved = bookmarks.some(bookmark => bookmark.url === tab.url);
    $('bookmark').classList.toggle('saved', saved); $('bookmark').setAttribute('aria-label', saved ? 'Remove bookmark' : 'Bookmark this page');
    $('progress').hidden = !tab.loading;
    $('start-page').hidden = Boolean(tab.url);
    $('error-page').hidden = !tab.error;
    if (tab.error) $('error-detail').textContent = tab.error;
    for (const candidate of tabs) if (candidate.frame) candidate.frame.frame.hidden = candidate.id !== activeId || !candidate.url || Boolean(candidate.error);
    document.title = tab.url ? tab.title + ' — Orbit' : 'Orbit — A more open web';
  }

  function activate(id) { activeId = id; renderTabs(); syncChrome(); }
  function addTab(url = '') {
    if (tabs.length >= 12) { toast('You can have up to 12 tabs open.'); return; }
    const tab = { id: ++nextId, title: 'New tab', url: '', frame: null, history: [''], cursor: 0, loading: false, error: '', navigation: 0, watchdog: null };
    tabs.push(tab); activate(tab.id);
    if (url) navigate(url, tab); else { $('search').value = ''; $('start-page').scrollTop = 0; $('search').focus({ preventScroll: true }); }
    return tab;
  }
  function closeTab(id) {
    const index = tabs.findIndex(tab => tab.id === id); if (index < 0) return;
    const tab = tabs[index]; tab.navigation++; clearTimeout(tab.watchdog); tab.frame?.frame.remove(); tabs.splice(index, 1);
    if (!tabs.length) addTab(); else activate(activeId === id ? tabs[Math.max(0, index - 1)].id : activeId);
  }
  function recordUrl(tab, url) {
    if (!/^https?:\/\//.test(url)) return;
    if (url === tab.url) return;
    tab.url = url; tab.title = new URL(url).hostname.replace(/^www\./, '');
    if (tab.replaying) tab.replaying = false;
    else if (tab.history[tab.cursor] !== url) { tab.history.splice(tab.cursor + 1); tab.history.push(url); tab.cursor = tab.history.length - 1; }
    renderTabs(); if (tab.id === activeId) syncChrome();
  }

  function createFrame(tab) {
    const frame = controller.createFrame(); tab.frame = frame;
    frame.frame.setAttribute('title', 'Proxied website'); frame.frame.setAttribute('allow', 'fullscreen; autoplay; encrypted-media'); frame.frame.referrerPolicy = 'no-referrer';
    frame.addEventListener('urlchange', event => recordUrl(tab, String(event.url)));
    frame.addEventListener('navigate', () => { tab.loading = true; if (tab.id === activeId) syncChrome(); });
    frame.frame.addEventListener('load', () => {
      if (!tab.url) return;
      tab.loading = false; clearTimeout(tab.watchdog);
      try {
        const title = frame.frame.contentDocument?.title;
        if (title && title !== 'about:blank') tab.title = title;
      } catch { /* A loading frame can temporarily be unavailable. */ }
      renderTabs(); if (tab.id === activeId) syncChrome();
    });
    $('frames').append(frame.frame);
    return frame;
  }

  async function navigate(value, tab = activeTab(), history = true) {
    if (!tab) return;
    let url;
    try { url = targetFor(value); } catch (error) { toast(error.message); return; }
    if (!url) return;
    const navigation = ++tab.navigation;
    tab.error = ''; tab.loading = true; tab.url = url; tab.title = new URL(url).hostname.replace(/^www\./, '');
    if (history && tab.history[tab.cursor] !== url) { tab.history.splice(tab.cursor + 1); tab.history.push(url); tab.cursor = tab.history.length - 1; }
    renderTabs(); if (tab.id === activeId) syncChrome();
    try {
      await initEngine();
      if (tab.navigation !== navigation || !tabs.includes(tab)) return;
      const frame = tab.frame || createFrame(tab);
      frame.frame.hidden = tab.id !== activeId;
      frame.go(url);
      clearTimeout(tab.watchdog);
      tab.watchdog = setTimeout(() => {
        if (tab.loading && tab.navigation === navigation) { tab.loading = false; if (tab.id === activeId) { syncChrome(); toast('This site is taking a while. You can reload or try another address.'); } }
      }, 45000);
    } catch (error) {
      if (tab.navigation !== navigation || !tabs.includes(tab)) return;
      tab.loading = false; tab.error = error.message; if (tab.id === activeId) syncChrome();
    }
  }

  function home(tab = activeTab(), history = true) {
    if (!tab) return;
    tab.navigation++; clearTimeout(tab.watchdog); tab.url = ''; tab.title = 'New tab'; tab.loading = false; tab.error = '';
    if (history && tab.history[tab.cursor] !== '') { tab.history.splice(tab.cursor + 1); tab.history.push(''); tab.cursor = tab.history.length - 1; }
    renderTabs(); syncChrome(); $('search').value = ''; $('start-page').scrollTop = 0; $('search').focus({ preventScroll: true });
  }
  function travel(offset) {
    const tab = activeTab(), next = tab.cursor + offset;
    if (next < 0 || next >= tab.history.length) return;
    tab.cursor = next; const target = tab.history[next];
    if (!target) home(tab, false); else navigate(target, tab, false);
  }

  function renderShortcuts() {
    $('shortcuts').replaceChildren();
    for (let index = 0; index < shortcuts.length; index++) {
      const shortcut = shortcuts[index];
      const item = document.createElement('div'); item.className = 'shortcut';
      const button = document.createElement('button'); button.className = 'shortcut-open'; button.setAttribute('aria-label', 'Open ' + shortcut.name);
      const mark = document.createElement('span'); mark.className = 'shortcut-icon';
      if (markSvg[shortcut.mark]) mark.innerHTML = markSvg[shortcut.mark]; else mark.textContent = shortcut.mark || shortcut.name.slice(0, 1).toUpperCase();
      const label = document.createElement('span'); label.textContent = shortcut.name; button.append(mark, label); button.onclick = () => navigate(shortcut.url);
      const remove = document.createElement('button'); remove.className = 'shortcut-remove'; remove.textContent = '×'; remove.setAttribute('aria-label', 'Remove ' + shortcut.name + ' shortcut');
      remove.onclick = () => { shortcuts.splice(index, 1); write('shortcuts', shortcuts); renderShortcuts(); };
      item.append(button, remove); $('shortcuts').append(item);
    }
  }

  function panel(label, html) { $('panel-label').textContent = label; $('panel-content').innerHTML = html; if (!$('panel').open) $('panel').showModal(); }
  const closePanel = () => $('panel').close();
  function showBookmarks() {
    panel('SAVED FOR LATER', '<h2>Your bookmarks.</h2><p>Keep the good corners of the web close.</p><div id="bookmark-list"></div>');
    if (!bookmarks.length) { $('bookmark-list').innerHTML = '<p class="setting-note">Visit a website and tap the star in the address bar to save it.</p>'; return; }
    bookmarks.forEach((bookmark, index) => {
      const row = document.createElement('div'); row.className = 'bookmark-row';
      const button = document.createElement('button'); button.textContent = bookmark.title;
      const hint = document.createElement('small'); hint.textContent = new URL(bookmark.url).hostname; button.append(hint); button.onclick = () => { closePanel(); navigate(bookmark.url); };
      const remove = document.createElement('button'); remove.className = 'icon-button'; remove.setAttribute('aria-label', 'Delete ' + bookmark.title); remove.innerHTML = icon('close');
      remove.onclick = () => { bookmarks.splice(index, 1); write('bookmarks', bookmarks); syncChrome(); showBookmarks(); };
      row.append(button, remove); $('bookmark-list').append(row);
    });
  }
  function showSettings() {
    panel('MAKE YOURSELF AT HOME', '<h2>A little more you.</h2><p>Personal touches for your space on the web.</p><label for="engine-select">Search engine</label><select id="engine-select"><option value="google">Google</option><option value="duckduckgo">DuckDuckGo</option><option value="bing">Bing</option></select><div class="setting-row"><span>Accent color</span><span id="swatches"></span></div><div class="setting-row"><span>Quick access</span><button id="reset-shortcuts" class="secondary" style="margin:0;padding:7px 10px;font-size:10px">Reset shortcuts</button></div><p class="setting-note">Settings and bookmarks are saved in this browser. Orbit does not keep a server browsing history.</p>');
    $('engine-select').value = engines[settings.engine] ? settings.engine : 'google';
    $('engine-select').onchange = event => { settings.engine = event.target.value; write('settings', settings); toast('Search engine updated.'); };
    [['#e7b263', 'Amber'], ['#afc1a6', 'Sage'], ['#bba8dc', 'Lavender']].forEach(([color, name]) => {
      const button = document.createElement('button'); button.className = 'swatch' + (settings.accent === color ? ' active' : ''); button.style.background = color; button.setAttribute('aria-label', name + ' accent');
      button.onclick = () => { settings.accent = color; write('settings', settings); applySettings(); showSettings(); };
      $('swatches').append(button);
    });
    $('reset-shortcuts').onclick = () => { shortcuts = defaultShortcuts.map(shortcut => ({ ...shortcut })); write('shortcuts', shortcuts); renderShortcuts(); toast('Original shortcuts restored.'); };
  }
  function showAbout() {
    panel('A MORE OPEN WEB', '<h2>Welcome to Orbit.</h2><p>Your personal browser, inspired by the simplicity of TungTung. Tabs, shortcuts, and a little room to explore.</p><div class="connection-detail">' + icon(ready ? 'check' : 'globe') + '<span id="about-status"></span></div><p>Website requests are relayed through this Cloudflare deployment. Scramjet rewrites pages so their links, scripts, and resources can load within Orbit.</p><p class="setting-note">Orbit is a web proxy, not a VPN or an anonymity service. Your network can see this domain, and may block it. Some websites, sign-ins, protected video, and anti-bot checks may not work. Browsing data can remain in this device’s storage. Avoid entering sensitive information into a web proxy.</p><p class="setting-note">Built with <a class="credits" href="https://github.com/MercuryWorkshop/scramjet" target="_blank" rel="noopener noreferrer">Scramjet</a> and <a class="credits" href="/licenses/" target="_blank" rel="noopener noreferrer">open-source components</a>.</p>');
    $('about-status').textContent = ready ? 'Cloudflare connection ready' : (routeError || 'Preparing the connection');
  }
  function showAddShortcut() {
    if (shortcuts.length >= 12) { toast('You can keep up to 12 shortcuts.'); return; }
    panel('A NEW FAVORITE', '<h2>Make it a shortcut.</h2><form id="shortcut-form"><label for="shortcut-name">Name</label><input id="shortcut-name" maxlength="20" required placeholder="My favorite corner"><label for="shortcut-url">Website address</label><input id="shortcut-url" type="text" required placeholder="https://example.com" spellcheck="false"><button class="primary" type="submit">Add shortcut</button></form>');
    $('shortcut-form').onsubmit = event => {
      event.preventDefault();
      const name = $('shortcut-name').value.trim(), value = $('shortcut-url').value.trim();
      if (!name) return;
      try {
        const url = targetFor(value);
        if (!/^https?:\/\//i.test(value) && /\s/.test(value)) throw new Error('Enter a website address for this shortcut.');
        shortcuts.push({ name, url, mark: name.slice(0, 1).toUpperCase() }); write('shortcuts', shortcuts); renderShortcuts(); closePanel(); toast('Shortcut added.');
      } catch (error) { toast(error.message); }
    };
  }

  $('new-tab').onclick = () => addTab();
  $('back').onclick = () => travel(-1); $('forward').onclick = () => travel(1);
  $('home').onclick = () => home(); $('rail-home').onclick = () => home();
  $('reload').onclick = () => { const tab = activeTab(); if (tab.url) navigate(tab.url, tab, false); };
  $('address-form').onsubmit = event => { event.preventDefault(); navigate($('address').value); $('address').blur(); };
  $('address').addEventListener('focus', () => $('address').select());
  $('search-form').onsubmit = event => { event.preventDefault(); navigate($('search').value); $('search').blur(); };
  $('bookmark').onclick = () => {
    const tab = activeTab(); if (!tab.url) return;
    const index = bookmarks.findIndex(bookmark => bookmark.url === tab.url);
    if (index < 0) { bookmarks.push({ title: tab.title, url: tab.url }); toast('Page bookmarked.'); }
    else { bookmarks.splice(index, 1); toast('Bookmark removed.'); }
    write('bookmarks', bookmarks); syncChrome();
  };
  $('fullscreen').onclick = async () => {
    try { if (document.fullscreenElement) await document.exitFullscreen(); else await document.documentElement.requestFullscreen(); }
    catch { toast('Fullscreen is unavailable in this browser.'); }
  };
  $('settings').onclick = showSettings; $('bookmarks').onclick = showBookmarks; $('about').onclick = showAbout; $('connection').onclick = showAbout;
  $('add-shortcut').onclick = showAddShortcut; $('close-panel').onclick = closePanel;
  $('panel').addEventListener('click', event => { if (event.target === $('panel')) { const box = $('panel').getBoundingClientRect(); if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) closePanel(); } });
  $('try-again').onclick = () => navigate(activeTab().url, activeTab(), false); $('error-home').onclick = () => home();
  document.addEventListener('keydown', event => {
    if (event.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName) && !$('panel').open) { event.preventDefault(); ($('start-page').hidden ? $('address') : $('search')).focus(); }
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key.toLowerCase() === 'l') { event.preventDefault(); $('address').focus(); }
  });
  function tick() { $('clock').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
  tick(); setInterval(tick, 30000); renderShortcuts(); addTab(); initEngine().catch(() => {});
})();
